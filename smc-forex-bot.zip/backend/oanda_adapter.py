import os
import requests
import pandas as pd

OANDA_URL = os.getenv("OANDA_API_URL", "https://api-fxpractice.oanda.com/v3")
API_KEY = os.getenv("OANDA_API_KEY")
ACCOUNT_ID = os.getenv("OANDA_ACCOUNT_ID")
HEADERS = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

def fetch_candles(instrument, granularity, count=200):
    url = f"{OANDA_URL}/instruments/{instrument}/candles"
    params = {"granularity": granularity, "count": count, "price": "M"}
    r = requests.get(url, headers=HEADERS, params=params)
    if r.status_code != 200:
        return pd.DataFrame()
    data = r.json().get('candles', [])
    rows = []
    for c in data:
        rows.append({
            'time': c.get('time'),
            'open': float(c['mid']['o']),
            'high': float(c['mid']['h']),
            'low': float(c['mid']['l']),
            'close': float(c['mid']['c'])
        })
    return pd.DataFrame(rows)

def place_market_order(instrument, units, takeProfit=None, stopLoss=None):
    url = f"{OANDA_URL}/accounts/{ACCOUNT_ID}/orders"
    order = {
        "order": {
            "instrument": instrument,
            "units": str(units),
            "type": "MARKET",
            "positionFill": "DEFAULT"
        }
    }
    if takeProfit or stopLoss:
        tp_sl = {}
        if takeProfit:
            tp_sl["takeProfitOnFill"] = {"price": str(takeProfit)}
        if stopLoss:
            tp_sl["stopLossOnFill"] = {"price": str(stopLoss)}
        order["order"].update(tp_sl)
    r = requests.post(url, headers=HEADERS, json=order)
    return r.json()
