import aiohttp
import asyncio
import os

NEWSAPI_KEY = os.getenv("NEWSAPI_KEY")
NEWS_ENDPOINT = "https://newsapi.org/v2/everything"

class NewsWatcher:
    def __init__(self, api_key=NEWSAPI_KEY):
        self.api_key = api_key
        self.seen = set()

    async def fetch(self, q="forex OR currency OR eurusd OR eur/usd", page=1):
        params = {"q": q, "language":"en", "pageSize":30, "page":page, "apiKey":self.api_key}
        async with aiohttp.ClientSession() as session:
            async with session.get(NEWS_ENDPOINT, params=params) as resp:
                return await resp.json()

    async def run(self, engine, interval=60):
        while True:
            try:
                data = await self.fetch()
                articles = data.get("articles", [])
                for a in articles:
                    url = a.get("url")
                    if url in self.seen: continue
                    self.seen.add(url)
                    title = a.get("title","").lower()
                    if any(k in title for k in ["rate", "interest rate", "nfp", "nonfarm", "pmi", "cpi", "inflation"]):
                        engine.add_signal({"symbol":"NEWS","side":"warn","msg":title, "url":url, "time": a.get("publishedAt")})
            except Exception as e:
                print("news watcher error:", e)
            await asyncio.sleep(interval)
