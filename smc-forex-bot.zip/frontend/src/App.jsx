import React, {useEffect, useState} from 'react'

export default function App(){
  const [signals, setSignals] = useState([]);
  async function fetchSignals(){
    try{
      const r = await fetch('/api/signals');
      const data = await r.json();
      setSignals(data.signals || []);
    }catch(e){ console.error(e) }
  }
  useEffect(()=>{
    fetchSignals();
    const iv = setInterval(fetchSignals, 5000);
    return ()=>clearInterval(iv);
  },[]);
  return (
    <div style={{padding:20}}>
      <h1>SMC Forex Bot — Signals</h1>
      <table border="1" cellPadding="6">
        <thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th>Entry</th><th>SL</th><th>TP</th><th>Lot</th><th>Note</th></tr></thead>
        <tbody>
          {signals.map((s,i)=>(
            <tr key={i}>
              <td>{s.timestamp || ''}</td>
              <td>{s.symbol}</td>
              <td>{s.side}</td>
              <td>{s.entry}</td>
              <td>{s.sl}</td>
              <td>{s.tp}</td>
              <td>{s.lot}</td>
              <td>{s.reason || s.msg || ''}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
