# SMC Forex Bot — MVP

This repository contains an MVP SMC-based Forex signal engine with TradingView webhook, News watcher, and a simple React frontend.

## Quick start (local/demo)
1. Copy `.env` from `backend/config.example.env` and fill keys.
2. Build and run with Docker Compose:
   docker-compose up --build
3. Backend: http://localhost:8000
   Frontend: http://localhost:3000
4. Create TradingView alert with webhook URL: https://your-server/webhook/tradingview

## Notes
- Use OANDA practice (demo) keys for testing.
- Do not run on live money before adequate backtesting.
