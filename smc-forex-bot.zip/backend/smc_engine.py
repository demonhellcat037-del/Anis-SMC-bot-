import pandas as pd
from datetime import datetime
from collections import deque
import os

RISK_PCT = float(os.getenv("RISK_PCT", 1.0))

class SMC_Engine:
    def __init__(self):
        self.signals = deque(maxlen=200)

    def add_signal(self, sig: dict):
        sig['timestamp'] = datetime.utcnow().isoformat()
        self.signals.appendleft(sig)

    def get_latest_signals(self):
        return list(self.signals)

    @staticmethod
    def position_size(account_balance, risk_pct, stop_loss_pips, pip_value_per_lot=10.0):
        if stop_loss_pips <= 0:
            return 0.01
        risk_amount = account_balance * (risk_pct / 100.0)
        lot = risk_amount / (stop_loss_pips * pip_value_per_lot)
        return max(round(lot, 2), 0.01)

    @staticmethod
    def detect_trend(df):
        if len(df) < 10:
            return "sideways"
        y = df['close'].tail(20).values
        coef = pd.Series(y).diff().mean()
        if coef > 0:
            return "up"
        elif coef < 0:
            return "down"
        else:
            return "sideways"

    @staticmethod
    def find_order_blocks(df):
        obs = []
        df = df.copy().reset_index(drop=True)
        df['range'] = df['high'] - df['low']
        rolling_mean = df['range'].rolling(50, min_periods=1).mean()
        for i in range(1, len(df)):
            if df.loc[i-1, 'range'] > 1.6 * rolling_mean.loc[i-1]:
                obs.append({
                    "time": df.loc[i-1, 'time'],
                    "high": df.loc[i-1, 'high'],
                    "low": df.loc[i-1, 'low']
                })
        return obs

    @staticmethod
    def find_fvgs(df):
        fvgs = []
        for i in range(len(df)-2):
            c1, c2, c3 = df.iloc[i], df.iloc[i+1], df.iloc[i+2]
            if c1['high'] < c3['low']:
                fvgs.append({"low": c1['high'], "high": c3['low'], "time": c2['time']})
            if c1['low'] > c3['high']:
                fvgs.append({"low": c3['high'], "high": c1['low'], "time": c2['time']})
        return fvgs

    def generate_signals_from_data(self, symbol, df_4h, df_1h, df_15m, account_balance=1000):
        trend = self.detect_trend(df_4h)
        obs = self.find_order_blocks(df_1h)
        fvgs = self.find_fvgs(df_15m)
        for fvg in fvgs:
            for ob in obs:
                if fvg['low'] >= ob['low'] and fvg['high'] <= ob['high']:
                    side = "buy" if trend == "up" else "sell" if trend == "down" else None
                    if side:
                        entry = df_15m['close'].iloc[-1]
                        if side == "buy":
                            sl = fvg['low']
                            tp = entry + (entry - sl) * 2
                            sl_pips = abs(entry - sl) * 10000
                        else:
                            sl = fvg['high']
                            tp = entry - (sl - entry) * 2
                            sl_pips = abs(entry - sl) * 10000
                        lot = self.position_size(account_balance, RISK_PCT, sl_pips)
                        sig = dict(symbol=symbol, side=side, entry=entry, sl=round(sl,5), tp=round(tp,5), lot=lot, reason="SMC: FVG inside OB + TF trend")
                        self.add_signal(sig)
        return
