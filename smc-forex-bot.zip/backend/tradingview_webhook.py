import asyncio
from smc_engine import SMC_Engine
from oanda_adapter import fetch_candles

async def handle_tradingview_alert(payload: dict, engine: SMC_Engine):
    symbol = payload.get("symbol")
    df_4h = fetch_candles(symbol, 'H4', 300)
    df_1h = fetch_candles(symbol, 'H1', 300)
    df_15m = fetch_candles(symbol, 'M15', 500)
    if df_15m is None or df_15m.empty:
        return
    engine.generate_signals_from_data(symbol, df_4h, df_1h, df_15m)
