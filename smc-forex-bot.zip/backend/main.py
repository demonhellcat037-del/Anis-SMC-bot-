import os
import asyncio
from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from dotenv import load_dotenv
from tradingview_webhook import handle_tradingview_alert
from smc_engine import SMC_Engine
from news_adapter import NewsWatcher

load_dotenv()
app = FastAPI(title="SMC Forex Bot")

engine = SMC_Engine()
news = NewsWatcher(api_key=os.getenv("NEWSAPI_KEY"))

class TVPayload(BaseModel):
    symbol: str
    timeframe: str
    secret: str
    extra: dict = {}

@app.post("/webhook/tradingview")
async def tradingview_webhook(payload: TVPayload, background: BackgroundTasks):
    if payload.secret != os.getenv("TRADINGVIEW_SECRET"):
        raise HTTPException(status_code=403, detail="Invalid secret")
    background.add_task(handle_tradingview_alert, payload.dict(), engine)
    return {"status": "accepted"}

@app.get("/api/signals")
async def get_signals():
    return {"signals": engine.get_latest_signals()}

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(news.run(engine))
